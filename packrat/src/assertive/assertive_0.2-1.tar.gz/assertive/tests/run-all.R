library(testthat)
library(assertive)

test_package("assertive")
